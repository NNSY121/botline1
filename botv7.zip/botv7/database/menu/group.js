const group = (pushname, prefix, botName, ownerName, _registered) => {
	return `-----[ *GROUP MENU* ]-----
Hallo, ${pushname} 👋
Semoga harimu Menyenangkan ✨
╭━━•✵ ⃟  ⃟  ⃟✵•━━━━━━━━━━━━━╮ุุุุุุุุุุ
┃╭────────┈┈✩̣̣̣̣*──➤ ↶↷*
┃│ ુོ➪ Nama BOT : ${botName}
┃│ ુོ➪ Prefix :「  ${prefix}  」
┃│ ુོ➪ USER ${botName} : ${_registered.length}
┃╰┈──────────────⩵꙰ཱི࿐
╰━━━━━━━━━━━━━━━━━━━━╯
Berikut adalah fitur yang ada pada bot ini!✨
╭━━•✵ ⃟  ⃟  ⃟✵•━━━━━━━━━━━━━╮ุุุุุุุุุุ
┃╭────────┈┈✩̣̣̣̣*──➤ ↶↷*
┃│ ુོ➪ *${prefix}add*
┃│ ુོ➪ *${prefix}kick*
┃│ ુོ➪ *${prefix}tagme*
┃│ ુོ➪ *${prefix}promote*
┃│ ુོ➪ *${prefix}demote*
┃│ ુོ➪ *${prefix}opengrup*
┃│ ુོ➪ *${prefix}closegrup*
┃│ ુོ➪ *${prefix}listadmin*
┃│ ુོ➪ *${prefix}linkgrup*
┃│ ુོ➪ *${prefix}ownergrup*
┃│ ુོ➪ *${prefix}leave*
┃│ ુོ➪ *${prefix}tagall*
┃│ ુོ➪ *${prefix}delete*
┃│ ુོ➪ *${prefix}mining*
┃│ ુོ➪ *${prefix}welcome*
┃│ ુོ➪ *${prefix}leveling*
┃│ ુོ➪ *${prefix}simih*
┃│ ુོ➪ *${prefix}nsfw*
┃│ ુོ➪ *${prefix}hidetag*
┃│ ુོ➪ *${prefix}hidetag5*
┃│ ુོ➪ *${prefix}hidetag20*
┃│ ુོ➪ *${prefix}hidetag50*
┃╰┈──────────────⩵꙰ཱི࿐
╰━━━━━━━━━━━━━━━━━━━━╯
-----[ *POWERED BY ${ownerName}* ]-----`
}
exports.group = group