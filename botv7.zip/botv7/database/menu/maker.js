const maker = (pushname, prefix, botName, ownerName, _registered) => {
	return `-----[ *MAKER MENU* ]-----
Hallo, ${pushname} 👋
Semoga harimu Menyenangkan ✨
╭━━•✵ ⃟  ⃟  ⃟✵•━━━━━━━━━━━━━╮ุุุุุุุุุุ
┃╭────────┈┈✩̣̣̣̣*──➤ ↶↷*
┃│ ુོ➪ Nama BOT : ${botName}
┃│ ુོ➪ Prefix :「  ${prefix}  」
┃│ ુོ➪ USER ${botName} : ${_registered.length}
┃╰┈──────────────⩵꙰ཱི࿐
╰━━━━━━━━━━━━━━━━━━━━╯
Berikut adalah fitur yang ada pada bot ini!✨
╭━━•✵ ⃟  ⃟  ⃟✵•━━━━━━━━━━━━━╮ุุุุุุุุุุ
┃╭────────┈┈✩̣̣̣̣*──➤ ↶↷*
┃│ ુོ➪ *${prefix}hartatahta*
┃│ ુོ➪ *${prefix}pornhub*
┃│ ુོ➪ *${prefix}thundername*
┃│ ુོ➪ *${prefix}bannerff*
┃│ ુོ➪ *${prefix}balonlove*
┃│ ુོ➪ *${prefix}galaxytext*
┃│ ુོ➪ *${prefix}glitchtext*
┃│ ુོ➪ *${prefix}lovetext*
┃│ ુོ➪ *${prefix}sakuratext*
┃│ ુོ➪ *${prefix}gugeltext*
┃│ ુོ➪ *${prefix}romancetext*
┃│ ુོ➪ *${prefix}partytext*
┃│ ુོ➪ *${prefix}gamelogo*
┃│ ુོ➪ *${prefix}blackpink*
┃│ ુོ➪ *${prefix}silktext*
┃│ ુོ➪ *${prefix}makelogoml*
┃│ ુོ➪ *${prefix}makelogoff*
┃│ ુོ➪ *${prefix}gemboktext*
┃│ ુོ➪ *${prefix}metaltext*
┃│ ુོ➪ *${prefix}apitext*
┃│ ુོ➪ *${prefix}airtext*
┃╰┈──────────────⩵꙰ཱི࿐
╰━━━━━━━━━━━━━━━━━━━━╯
-----[ *POWERED BY ${ownerName}* ]-----`
}
exports.maker = maker