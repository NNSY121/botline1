const other = (pushname, prefix, botName, ownerName, _registered) => {
	return `-----[ *OTHER MENU* ]-----
Hallo, ${pushname} 👋
Semoga harimu Menyenangkan ✨
╭━━•✵ ⃟  ⃟  ⃟✵•━━━━━━━━━━━━━╮ุุุุุุุุุุ
┃╭────────┈┈✩̣̣̣̣*──➤ ↶↷*
┃│➸ Nama BOT : ${botName}
┃│➸ Prefix :「  ${prefix}  」
┃│➸ USER ${botName} : ${_registered.length}
┃╰┈──────────────⩵꙰ཱི࿐
╰━━━━━━━━━━━━━━━━━━━━╯
Berikut adalah fitur yang ada pada bot ini!✨
╭━━•✵ ⃟  ⃟  ⃟✵•━━━━━━━━━━━━━╮ุุุุุุุุุุ
┃╭────────┈┈✩̣̣̣̣*──➤ ↶↷*
┃│➸ *${prefix}timer*
┃│➸ *${prefix}bahasa*
┃│➸ *${prefix}virtex*
┃│➸ *${prefix}kodenegara*
┃│➸ *${prefix}wame*
┃│➸ *${prefix}wiki*
┃│➸ *${prefix}kbbi*
┃│➸ *${prefix}testime*
┃│➸ *${prefix}fakta*
┃│➸ *${prefix}game*
┃│➸ *${prefix}infocuaca*
┃│➸ *${prefix}quran*
┃│➸ *${prefix}nangis*
┃│➸ *${prefix}peluk*
┃│➸ *${prefix}cium*
┃│➸ *${prefix}jadwaltv*
┃╰┈──────────────⩵꙰ཱི࿐
╰━━━━━━━━━━━━━━━━━━━━╯
-----[ *POWERED BY ${ownerName}* ]-----`
}
exports.other = other