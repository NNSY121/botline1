#!/usr/bin/bash

npm i -g cwebp
npm i -g ytdl
npm i node-tesseract-ocr
npm i
wget -O ~/../usr/share/tessdata/ind.traineddata "https://github.com/tesseract-ocr/tessdata/blob/master/ind.traineddata?raw=true"
npm i imgbb-uploader
npm cache clean -f
npm install
npm i got

echo "[*] Ketik perintah berikut \"npm start\" Jangan lupa subscribe YT Ramlan Channel"
#!/usr/bin/bash
